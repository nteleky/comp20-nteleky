
//=============================================================================
// Assignment 5: Scorecenter
// Comp20 2013
// April 18, 2013
// Nicholas Teleky
//=============================================================================

//Express initialization
var express = require("express");
var app = express();
app.use(express.logger());
app.use(express.bodyParser());
app.use(app.router);
app.set('scorecenter', 'nodeapp');

//MongoDB initialization
var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 'mongodb://comp20:ming@ds033067.mongolab.com:33067/heroku_app15131730';
  var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});



//Allows for CORS
app.all('*', function(request, response, next) {
    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");
    next();
});

//----------------------------------------------------------------------------
//Home root of app; displays list of all scores for games.
//----------------------------------------------------------------------------
app.get('/', function (request, response) {
    var output = "<!DOCTYPE html><html><head><title>Teleky Scorecenter</title></head><body>";
    db.collection('scores', function(er, collection) {
        collection.find().toArray(function(err, scores) {
            if (er || scores.length==0) {
                output += "<div id ='noscore'><h1>No scores. Play some games!</h1></div>";
            } else {
                output += "<div id='scores'><h1>Scores</h1><br><ol>";
                for (var i = 0; i < scores.length; i++) {
                    output += "<li>" + scores[i].game_title + "    " + scores[i].username + "   " + scores[i].score + "</li>";
                }
                output += "</ol></div>"
            } 
            output += "</body></html>";
            response.set('Content-Type', 'text/html');
	        response.send(output);
        });
    
    });

});

//----------------------------------------------------------------------------
//POST API; allows any HTML5 game to send high scores.
//----------------------------------------------------------------------------
app.post('/submit.json', function(request, response) {
	var d = new Date();
    response.set('Content-Type', 'text/json');
    db.collection('scores', function(er, collection) {
        collection.insert({score: request.body.score, game_title:request.body.game_title, username:request.body.username, created_at:d}, function(err, success) {
            if (err || !success) response.end(err);
            else response.end("Score sent at: " + d);
        });
    });
});

//----------------------------------------------------------------------------
//GET API; Returns top 10 high scores in descending order as JSON. 
//----------------------------------------------------------------------------
app.get('/highscores.json', function(request, response) {
	response.set('Content-Type', 'text/json');
    db.collection('scores', function(er, collection) {
       collection.find({game_title:request.query.game_title}).sort({score:-1}).limit(10).toArray(function(err, scores) {
            if(err || !scores) response.end('[]');
            else response.end(JSON.stringify(scores));
       });
    });
});

//----------------------------------------------------------------------------
//Usersearch; Allows a user to search for all scores from a user. 
//----------------------------------------------------------------------------
app.get('/usersearch', function(request, response) {
    response.set('Content-Type', 'text/html');
    if ((request.query.username != undefined) && (request.query.username != "")) {
        db.collection('scores', function (er, collection) {
            collection.find({username:request.query.username}).sort({score:-1}).toArray(function(err, results) {
                if (err || !results) response.send('[]');
                else {
                    var output = "<!DOCTYPE><html><head></head><body><form>Username: <input id=\"data\" type=\"search\" name=\"username\"><br><input type=\"submit\" value=\"Search\" onclick=\"get_data()\"></form><br><br><h1>Score results for: " + request.query.username + " </h1><table border=\"1\"><tr><th>Game</th><th>Score</th><th>Created On</th></<tr>";
                    for (var i = 0; i < results.length; i++) {
                        output += "<tr><td>" + results[i].game_title + "</td><td>" + results[i].score + "</td><td>" + results[i].created_at + "</td></tr>";
                    }
                    output += "</table>";
                    if(results.length == 0) output +="<p>No scores found</p>";
                    output += "</body></html>";
                    response.send(output);
                }
            });
        });
    } else {
        var output = "<!DOCTYPE><html><head></head><body><form>Username: <input id=\"data\" type=\"search\" name=\"username\"><br><input type=\"submit\" value=\"Search\" onclick=\"get_data()\"></form></body></html>";
        response.send(output);
    }
});


app.listen(process.env.PORT || 5000);
