Assignment 5: Scorecenter
=======================
Programmer: Nicholas Teleky
------------------------
Due date: 4/18/2013
------------------------


Implemented Correctly:
--------------------
* MongoDB and Node.js working properly with heroku
* Usersearch - search users and return results for just that user.
* POST and GET APIs - work as expected when tested via terminal.
* JSON implementation working properly

Implemented Incorrectly:
--------------------------
* Sort -- was having trouble with the sort method.

Hours spent: Approximately 15
